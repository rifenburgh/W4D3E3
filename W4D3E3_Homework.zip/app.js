/*
Create Folder
touch app.js
npm init
mkdir public/images
mkdir views
npm install --save express
npm install --save ejs
npm install --save express-ejs-layouts
mkdir views/layouts
touch views/layouts/main-layouts.ejs


Open App.js

const express = require("express");
const expressLayouts = require('express-ejs-layouts');
const app = express(); //creates 'instance' of Express
app.set('views', __dirname + '/views'); //point Express to EJS/HTML files in the Views folder
app.set('view engine', 'ejs'); //Express will use EJS package for files in Views
app.use(express.static('public')); //makes the Public folder public http://localhost:3000/images/1.png
app.use(expressLayouts); // for layout templates
app.set('layout', 'layouts/main-layout');



*/
const cows = require('cows');
const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const app = express();
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');
app.use(express.static('public'));
app.use(expressLayouts);
app.set('layout', 'layout/main-layout');


app.get('/', (req, res, next) => {
  res.render('index');
});
app.get('/page1', (req, res, next) => {
  res.render('page1');
});
app.get('/page2', (req, res, next) => {
  const monkey = cows();
  const randomNumber = Math.floor(Math.random() * 423);
  const dog = monkey[randomNumber];
  console.log(monkey.length);
  res.render('page2', {
    dog: dog
  });
});
app.listen(3000, () => {
  console.log("W4D3E3 site is working.");
});
